﻿using Parcial_Programacion;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace mascotasWeb
{
    public partial class Formulario_web12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void BtConsultar_Click(object sender, EventArgs e)
        {
            int id ;
            id = Int32.Parse(txCod.Text);
            SqlConnection conexion = DB.conectar("VETERINARIA");
            String sql = "Select * From mascota Where mascota_id = '" + id + "'";

            SqlDataReader tabla = DB.consulta(sql, conexion);
            if (tabla.Read())
            {
                txNom.Text = tabla[1].ToString();
                txEspecie.Text = tabla["especie"].ToString();
                txRaza.Text = tabla["raza"].ToString();
                txFecha.Text = tabla["fecha_nacimiento"].ToString();
                //lbMensaje.Text = "La mascota existe";
                if (Int32.Parse(txCod.Text) == 1)
                {
                    pastor.Visible = true;
                }
                if (Int32.Parse(txCod.Text) == 2)
                {
                    persa.Visible = true;
                }
                if (Int32.Parse(txCod.Text) == 3)
                {
                    criollo.Visible = true;
                }
                if (Int32.Parse(txCod.Text) == 4)
                {
                    perroblanco.Visible = true;
                }
            }
            else
            {

                lbMensaje.Text = "La mascota no existe";
                txCod.Text = "";
                txNom.Text = "";
                txRaza.Text = "";
                txEspecie.Text = "";
                txFecha.Text = "";
                txCod.Focus();
            }
        }

        protected void BtBorrar_Click(object sender, EventArgs e)
        {
            txCod.Text = "";
            txNom.Text = "";
            txRaza.Text = "";
            txEspecie.Text = "";
            txFecha.Text = "";
            txCod.Focus();
        }

        protected void BtRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx");
        }
    }
}