﻿using Parcial_Programacion;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mascotasWeb
{
    public partial class Formulario_web11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtConsultar_Click(object sender, EventArgs e)
        {
            string nom = "";
            nom = txNom.Text;
            SqlConnection conexion = DB.conectar("VETERINARIA");
            String sql = "Select * From mascota Where nombre_mascota = '" + nom + "'";

            SqlDataReader tabla = DB.consulta(sql, conexion);
            if (tabla.Read())
            {
                txCod.Text = tabla[0].ToString();
                txEspecie.Text = tabla["especie"].ToString();
                txRaza.Text = tabla["raza"].ToString();
                txFecha.Text = tabla["fecha_nacimiento"].ToString();
                //lbMensaje.Text = "La mascota existe";

                if (txNom.Text == "Max")
                {
                    pastor.Visible = true;
                }
                if (txNom.Text == "Mora")
                {
                    persa.Visible = true;
                }
                if (txNom.Text == "Coco")
                {
                    criollo.Visible = true;
                }
                if (txNom.Text == "Misifu")
                {
                    perroblanco.Visible = true;
                }
            }
            else
            {

                lbMensaje.Text = "La mascota no existe";
                txCod.Text = "";
                txNom.Text = "";
                txRaza.Text = "";
                txEspecie.Text = "";
                txFecha.Text = "";
                txNom.Focus();
            }
        }

        protected void BtBorrar_Click(object sender, EventArgs e)
        {
            txCod.Text = "";
            txNom.Text = "";
            txRaza.Text = "";
            txEspecie.Text = "";
            txFecha.Text = "";
            txNom.Focus();
        }

        protected void BtRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx");
        }
    }
}